@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv (
  echo Instalando dependencias, solo la primera vez...
  python -m venv .venv
  .venv\Scripts\python -m pip install -r requirements.txt
)
.venv\Scripts\python src\py\Player.py
