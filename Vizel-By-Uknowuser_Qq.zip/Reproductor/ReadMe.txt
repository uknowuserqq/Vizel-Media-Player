 LOCAL PLAYER (audio only)

1) Copy your songs:
     playlist/mp3 → .mp3 .m4a .wav .ogg .flac
     playlist/mp4 → .mp4 .m4v .webm (audio only plays)
   Subfolders can be used.

2) Start the app:
     Windows: Double click start.bat
     Linux/Mac: ./start.sh
   (first time install pywebview automatically; Python 3.9+ required)

3) Keyboard shortcuts:
     Play/pause space N / P next / previous
     ← → -5 s / +5 s ↑ ↓ volume
     S random R repeat (off /list /one)
     M mute/search

Configuration:
  src/py/Player.config volume, random, repeat, folders and extensions
  src/py/PyWebview-Window.config window title, size and options

Structure:
  playlist/mp3, playlist/mp4
  src/Webview/background.html, index.html, Views.css, javaScript.js
  src/py/Player.py, Player.config, PyWebview-Window.config

--------------------------------------------------------------------------------------------------------------
--- > BY t.me/Uknowuser_Qq
--------------------------------------------------------------------------------------------------------------