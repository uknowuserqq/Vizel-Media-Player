(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const audio = new Audio();
  audio.preload = 'metadata';

  const el = {
    title: $('title'), subtitle: $('subtitle'), disc: $('disc'), discEmoji: $('discEmoji'),
    cur: $('cur'), dur: $('dur'), seek: $('seek'), vol: $('vol'),
    play: $('btnPlay'), prev: $('btnPrev'), next: $('btnNext'),
    shuffle: $('btnShuffle'), repeat: $('btnRepeat'), mute: $('btnMute'), refresh: $('btnRefresh'),
    addPlaylist: $('btnAddPlaylist'),
    search: $('search'), list: $('tracks'), count: $('count'), empty: $('empty'),
    toast: $('toast'), bg: $('bg'),
  };

  const state = {
    tracks: [], filter: 'all', query: '',
    currentId: null, shuffle: false, repeat: 'all',
    history: [], errors: 0, seeking: false,
  };
  const REPEAT_TEXT = { off: 'Repetir: desactivado', all: 'Repetir: toda la lista', one: 'Repetir: una cancion' };

  const fmt = (s) => {
    if (!isFinite(s)) return '0:00';
    s = Math.floor(s);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(r).padStart(2, '0');
  };
  const fill = (input) => {
    const p = ((input.value - input.min) / (input.max - input.min)) * 100;
    input.style.setProperty('--p', p + '%');
  };
  let toastTimer;
  const toast = (msg) => {
    el.toast.textContent = msg;
    el.toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.remove('show'), 2400);
  };
  const api = () => (window.pywebview && window.pywebview.api) || null;
  let saveTimer;
  const saveSettings = () => {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      const a = api();
      if (a) a.save_settings({ volume: audio.volume, shuffle: state.shuffle, repeat: state.repeat }).catch(() => {});
    }, 400);
  };

  const updateIcons = () => {
    if (window.lucide) window.lucide.createIcons();
  };

  const current = () => state.tracks.find((t) => t.id === state.currentId) || null;
  const visible = () => {
    const q = state.query.trim().toLowerCase();
    return state.tracks.filter((t) =>
      (state.filter === 'all' || t.type === state.filter) && (!q || t.title.toLowerCase().includes(q)));
  };

  function renderList() {
    const items = visible();
    el.list.replaceChildren();
    for (const t of items) {
      const li = document.createElement('li');
      li.className = 'track' + (t.id === state.currentId ? ' active' : '');
      li.dataset.id = t.id; li.dataset.type = t.type;
      li.title = `${t.title}.${t.ext} · ${t.size} MB`;

      const ico = document.createElement('span'); ico.className = 'ico';
      const isPlayingTrack = (t.id === state.currentId && !audio.paused);
      ico.innerHTML = `<i data-lucide="${isPlayingTrack ? 'volume-2' : (t.type === 'mp4' ? 'video' : 'music')}"></i>`;
      
      const name = document.createElement('span'); name.className = 'name'; name.textContent = t.title;
      const tag = document.createElement('span'); tag.className = 'tag'; tag.textContent = t.ext;
      li.append(ico, name, tag);
      li.addEventListener('click', () => play(t.id));
      el.list.append(li);
    }
    el.count.textContent = state.tracks.length
      ? `${items.length} de ${state.tracks.length} canciones`
      : '';
    el.empty.hidden = state.tracks.length > 0;
    updateIcons();
  }

  function markActive() {
    el.list.querySelectorAll('.track').forEach((li) => {
      const active = li.dataset.id === state.currentId;
      li.classList.toggle('active', active);
      const t = state.tracks.find((x) => x.id === li.dataset.id);
      const isPlayingTrack = (active && !audio.paused);
      li.querySelector('.ico').innerHTML = `<i data-lucide="${isPlayingTrack ? 'volume-2' : (t.type === 'mp4' ? 'video' : 'music')}"></i>`;
      if (active) li.scrollIntoView({ block: 'nearest' });
    });
    updateIcons();
  }

  function play(id, { fromHistory = false } = {}) {
    const t = state.tracks.find((x) => x.id === id);
    if (!t) return;
    if (!fromHistory && state.currentId && state.currentId !== id) state.history.push(state.currentId);
    state.currentId = id;
    audio.src = t.url;
    audio.play().catch(() => {});
    el.title.textContent = t.title;
    el.subtitle.textContent = t.type === 'mp4' ? 'Video reproducido solo como audio' : 'Audio';
    el.discEmoji.innerHTML = `<i data-lucide="${t.type === 'mp4' ? 'video' : 'music'}"></i>`;
    document.title = `${t.title} · Reproductor`;
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({ title: t.title, artist: 'Reproductor local' });
    }
    ensureAnalyser();
    markActive();
    updateIcons();
  }

  function togglePlay() {
    if (!state.currentId) {
      const list = visible();
      if (list.length) play((state.shuffle ? list[Math.floor(Math.random() * list.length)] : list[0]).id);
      return;
    }
    if (audio.paused) audio.play().catch(() => {}); else audio.pause();
  }

  function pickNext(auto) {
    const list = visible().length ? visible() : state.tracks;
    if (!list.length) return null;
    const i = list.findIndex((t) => t.id === state.currentId);
    if (state.shuffle) {
      if (list.length === 1) return list[0];
      let n; do { n = list[Math.floor(Math.random() * list.length)]; } while (n.id === state.currentId);
      return n;
    }
    if (i === -1) return list[0];
    if (i + 1 < list.length) return list[i + 1];
    return auto && state.repeat === 'off' ? null : list[0];
  }

  function next(auto = false) {
    const n = pickNext(auto);
    if (n) play(n.id);
    else { audio.pause(); audio.currentTime = 0; }
  }

  function prev() {
    if (audio.currentTime > 3) { audio.currentTime = 0; return; }
    if (state.history.length) { play(state.history.pop(), { fromHistory: true }); return; }
    const list = visible().length ? visible() : state.tracks;
    const i = list.findIndex((t) => t.id === state.currentId);
    if (list.length) play(list[(i - 1 + list.length) % list.length].id, { fromHistory: true });
  }

  audio.addEventListener('play', () => {
    el.play.innerHTML = '<i data-lucide="pause"></i>';
    el.disc.classList.add('spin');
    markActive();
    ensureAnalyser(true);
    updateIcons();
  });
  audio.addEventListener('pause', () => {
    el.play.innerHTML = '<i data-lucide="play"></i>';
    el.disc.classList.remove('spin');
    markActive();
    updateIcons();
  });
  audio.addEventListener('loadedmetadata', () => { el.dur.textContent = fmt(audio.duration); state.errors = 0; });
  audio.addEventListener('timeupdate', () => {
    el.cur.textContent = fmt(audio.currentTime);
    if (!state.seeking && audio.duration) {
      el.seek.value = (audio.currentTime / audio.duration) * 1000;
      fill(el.seek);
    }
  });
  audio.addEventListener('ended', () => {
    if (state.repeat === 'one') { audio.currentTime = 0; audio.play(); } else next(true);
  });
  audio.addEventListener('error', () => {
    const t = current();
    toast(`No se pudo reproducir ${t ? t.title : 'el archivo'}`);
    if (++state.errors < state.tracks.length) setTimeout(() => next(true), 600);
  });

  el.play.addEventListener('click', togglePlay);
  el.next.addEventListener('click', () => next(false));
  el.prev.addEventListener('click', prev);

  el.seek.addEventListener('input', () => { state.seeking = true; fill(el.seek); el.cur.textContent = fmt((el.seek.value / 1000) * audio.duration); });
  el.seek.addEventListener('change', () => {
    if (audio.duration) audio.currentTime = (el.seek.value / 1000) * audio.duration;
    state.seeking = false;
  });

  const setVolume = (v) => {
    audio.volume = Math.max(0, Math.min(1, v));
    audio.muted = audio.volume === 0;
    el.vol.value = Math.round(audio.volume * 100); fill(el.vol);
    el.mute.innerHTML = `<i data-lucide="${audio.muted || audio.volume === 0 ? 'volume-x' : (audio.volume < 0.4 ? 'volume-1' : 'volume-2')}"></i>`;
    updateIcons();
    saveSettings();
  };
  el.vol.addEventListener('input', () => setVolume(el.vol.value / 100));
  let lastVol = .8;
  el.mute.addEventListener('click', toggleMute);
  function toggleMute() {
    if (audio.muted || audio.volume === 0) { setVolume(lastVol || .8); }
    else { lastVol = audio.volume; audio.muted = true; el.mute.innerHTML = '<i data-lucide="volume-x"></i>'; el.vol.value = 0; fill(el.vol); updateIcons(); }
  }

  function setShuffle(on, silent) {
    state.shuffle = on;
    el.shuffle.classList.toggle('on', on);
    el.shuffle.setAttribute('aria-pressed', String(on));
    if (!silent) { toast(on ? 'Aleatorio activado' : 'Orden normal'); saveSettings(); }
  }
  function setRepeat(mode, silent) {
    state.repeat = mode;
    el.repeat.classList.toggle('on', mode !== 'off');
    if (!silent) { toast(REPEAT_TEXT[mode]); saveSettings(); }
  }
  el.shuffle.addEventListener('click', () => setShuffle(!state.shuffle));
  el.repeat.addEventListener('click', () => setRepeat({ off: 'all', all: 'one', one: 'off' }[state.repeat]));

  document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('active', x === b));
    state.filter = b.dataset.filter; renderList();
  }));
  el.search.addEventListener('input', () => { state.query = el.search.value; renderList(); });
  el.refresh.addEventListener('click', () => loadTracks(true));

  if (el.addPlaylist) {
    el.addPlaylist.addEventListener('click', async () => {
      const a = api();
      if (a && typeof a.add_playlist === 'function') {
        try { await a.add_playlist(); loadTracks(true); } catch (_) { toast('Error al abrir selector'); }
      } else {
        toast('Copia mas audios a playlist/mp3 o mp4');
      }
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.target === el.search) { if (e.key === 'Escape') { el.search.value = ''; state.query = ''; el.search.blur(); renderList(); } return; }
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const k = e.key.toLowerCase();
    const map = {
      ' ': togglePlay, 'n': () => next(false), 'p': prev, 's': () => setShuffle(!state.shuffle),
      'r': () => el.repeat.click(), 'm': toggleMute,
      'arrowright': () => { audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 5); },
      'arrowleft': () => { audio.currentTime = Math.max(0, audio.currentTime - 5); },
      'arrowup': () => setVolume(audio.volume + .05),
      'arrowdown': () => setVolume(audio.volume - .05),
      '/': () => el.search.focus(),
    };
    if (map[k]) { e.preventDefault(); map[k](); }
  });

  if ('mediaSession' in navigator) {
    const ms = navigator.mediaSession;
    ms.setActionHandler('play', togglePlay);
    ms.setActionHandler('pause', togglePlay);
    ms.setActionHandler('previoustrack', prev);
    ms.setActionHandler('nexttrack', () => next(false));
  }

  let analyser, ctxAudio, data;
  function ensureAnalyser(resume) {
    try {
      if (!ctxAudio) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        ctxAudio = new AC();
        const src = ctxAudio.createMediaElementSource(audio);
        analyser = ctxAudio.createAnalyser(); analyser.fftSize = 256;
        data = new Uint8Array(analyser.frequencyBinCount);
        src.connect(analyser); analyser.connect(ctxAudio.destination);
      }
      if (resume && ctxAudio.state === 'suspended') ctxAudio.resume();
    } catch (_) {}
  }
  function tickBackground() {
    let level = 0;
    if (analyser && !audio.paused) {
      analyser.getByteFrequencyData(data);
      let sum = 0; for (let i = 0; i < 24; i++) sum += data[i];
      level = sum / 24 / 255;
    } else if (!audio.paused) level = .3;
    if (el.bg.contentWindow) el.bg.contentWindow.postMessage({ type: 'state', playing: !audio.paused, level }, '*');
    requestAnimationFrame(tickBackground);
  }

  async function loadTracks(manual) {
    const a = api();
    if (!a) {
      el.empty.hidden = false;
      el.empty.querySelector('p').textContent = 'Modo de vista previa sin backend';
      el.empty.querySelector('small').textContent = 'Abri la aplicacion usando Player.py para conectar tus canciones.';
      return;
    }
    try {
      state.tracks = await a.list_tracks();
      if (state.currentId && !current()) state.currentId = null;
      renderList();
      if (manual) toast(`${state.tracks.length} canciones encontradas`);
    } catch (err) {
      toast('No se pudo leer la playlist');
    }
  }

  async function init() {
    const a = api();
    let cfg = { volume: .8, shuffle: false, repeat: 'all', autoplay: false };
    if (a) { try { cfg = Object.assign(cfg, await a.get_config()); } catch (_) {} }
    lastVol = cfg.volume || .8;
    setVolume(cfg.volume);
    setShuffle(!!cfg.shuffle, true);
    setRepeat(['off', 'all', 'one'].includes(cfg.repeat) ? cfg.repeat : 'all', true);
    fill(el.seek);
    await loadTracks(false);
    if (cfg.autoplay && state.tracks.length) togglePlay();
    tickBackground();
    updateIcons();
  }

  if (window.pywebview && window.pywebview.api) init();
  else {
    window.addEventListener('pywebviewready', init);
    setTimeout(() => { if (!api() && !state.tracks.length) init(); }, 2500);
  }
})();