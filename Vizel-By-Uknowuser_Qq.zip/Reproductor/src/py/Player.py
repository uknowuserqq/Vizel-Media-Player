
import json
import mimetypes
import re
import threading
import urllib.parse
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import webview

BASE = Path(__file__).resolve().parent          
ROOT = BASE.parent.parent                       
CONFIG_FILE = BASE / "Player.config"
WINDOW_FILE = BASE / "PyWebview-Window.config"

DEFAULT_WINDOW = {
    "title": "Reproductor local",
    "width": 1040,
    "height": 640,
    "min_size": [760, 520],
    "resizable": True,
    "frameless": False,
    "easy_drag": False,
    "on_top": False,
    "fullscreen": False,
    "text_select": False,
    "confirm_close": False,
    "background_color": "#14111f",
    "debug": False,
}

DEFAULT_CONFIG = {
    "server": {"host": "127.0.0.1", "port": 0},
    "playlist": {
        "folders": {"mp3": "playlist/mp3", "mp4": "playlist/mp4"},
        "extensions": {
            "mp3": [".mp3", ".m4a", ".wav", ".ogg", ".flac"],
            "mp4": [".mp4", ".m4v", ".webm"],
        },
    },
    "player": {"volume": 0.8, "shuffle": False, "repeat": "all", "autoplay": False},
}

mimetypes.add_type("video/mp4", ".mp4")
mimetypes.add_type("video/mp4", ".m4v")
mimetypes.add_type("audio/mpeg", ".mp3")
mimetypes.add_type("audio/mp4", ".m4a")
mimetypes.add_type("audio/flac", ".flac")
mimetypes.add_type("text/javascript", ".js")



def _read_json(path: Path, default: dict) -> dict:
    merged = json.loads(json.dumps(default))
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return merged
    for key, value in data.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key].update(value)
        else:
            merged[key] = value
    return merged


def load_config() -> dict:
    return _read_json(CONFIG_FILE, DEFAULT_CONFIG)


def load_window() -> dict:
    return _read_json(WINDOW_FILE, DEFAULT_WINDOW)


def natural_key(text: str):
    return [int(p) if p.isdigit() else p.lower() for p in re.split(r"(\d+)", text)]



class Api:
    """Métodos que se pueden llamar desde JavaScript: pywebview.api.<metodo>()"""

    def get_config(self):
        return load_config()["player"]

    def list_tracks(self):
        cfg = load_config()["playlist"]
        tracks = []
        for kind, folder in cfg["folders"].items():
            directory = ROOT / folder
            directory.mkdir(parents=True, exist_ok=True)
            exts = {e.lower() for e in cfg["extensions"].get(kind, [])}
            files = [f for f in directory.rglob("*") if f.is_file() and f.suffix.lower() in exts]
            for f in sorted(files, key=lambda p: natural_key(p.name)):
                rel = f.relative_to(ROOT).as_posix()
                tracks.append(
                    {
                        "id": rel,
                        "title": f.stem,
                        "type": kind,
                        "ext": f.suffix.lower().lstrip("."),
                        "size": round(f.stat().st_size / (1024 * 1024), 1),
                        "url": "/" + urllib.parse.quote(rel),
                    }
                )
        return tracks

    def save_settings(self, data):
        allowed = {"volume": float, "shuffle": bool, "repeat": str}
        try:
            raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            raw = json.loads(json.dumps(DEFAULT_CONFIG))
        player = raw.setdefault("player", {})
        for key, cast in allowed.items():
            if key in data:
                player[key] = cast(data[key])
        try:
            CONFIG_FILE.write_text(json.dumps(raw, indent=2, ensure_ascii=False), encoding="utf-8")
        except OSError:
            return False
        return True



class Handler(SimpleHTTPRequestHandler):
    """Sirve solo /src/Webview y /playlist, con soporte de Range (seek)."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def log_message(self, *args): 
        pass

    def _allowed(self) -> bool:
        path = urllib.parse.unquote(self.path.split("?", 1)[0])
        return path.startswith("/src/Webview/") or path.startswith("/playlist/")

    def send_head(self):
        if not self._allowed():
            self.send_error(403, "Prohibido")
            return None
        path = Path(self.translate_path(self.path)).resolve()
        allowed_dirs = ((ROOT / "src" / "Webview").resolve(), (ROOT / "playlist").resolve())
        if not any(path.is_relative_to(d) for d in allowed_dirs):
            self.send_error(403, "Prohibido")
            return None
        if not path.is_file():
            self.send_error(404, "No encontrado")
            return None

        size = path.stat().st_size
        start, end, status = 0, size - 1, 200
        match = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", ""))
        if match and size > 0:
            first, last = match.groups()
            if first == "" and last:
                start = max(size - int(last), 0)
            else:
                start = int(first) if first else 0
                end = min(int(last), size - 1) if last else size - 1
            if start > end or start >= size:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{size}")
                self.end_headers()
                return None
            status = 206

        try:
            handle = open(path, "rb")
        except OSError:
            self.send_error(404, "No encontrado")
            return None
        handle.seek(start)
        self._remaining = end - start + 1

        self.send_response(status)
        self.send_header("Content-Type", self.guess_type(str(path)))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(self._remaining))
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        return handle

    def do_GET(self):
        handle = self.send_head()
        if not handle:
            return
        try:
            remaining = self._remaining
            while remaining > 0:
                chunk = handle.read(min(64 * 1024, remaining))
                if not chunk:
                    break
                self.wfile.write(chunk)
                remaining -= len(chunk)
        except (ConnectionError, OSError):
            pass  # el reproductor cortó la conexión (cambio de tema / seek)
        finally:
            handle.close()

    def do_HEAD(self):
        handle = self.send_head()
        if handle:
            handle.close()


def start_server(host: str, port: int) -> ThreadingHTTPServer:
    server = ThreadingHTTPServer((host, port), Handler)
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server



def main():
    config = load_config()
    win = load_window()

    for folder in config["playlist"]["folders"].values():
        (ROOT / folder).mkdir(parents=True, exist_ok=True)

    server = start_server(config["server"]["host"], int(config["server"]["port"]))
    host, port = server.server_address[:2]

    webview.create_window(
        win["title"],
        url=f"http://{host}:{port}/src/Webview/index.html",
        js_api=Api(),
        width=int(win["width"]),
        height=int(win["height"]),
        min_size=tuple(win["min_size"]),
        resizable=bool(win["resizable"]),
        frameless=bool(win["frameless"]),
        easy_drag=bool(win["easy_drag"]),
        on_top=bool(win["on_top"]),
        fullscreen=bool(win["fullscreen"]),
        text_select=bool(win["text_select"]),
        confirm_close=bool(win["confirm_close"]),
        background_color=win["background_color"],
    )
    webview.start(debug=bool(win["debug"]))
    server.shutdown()


if __name__ == "__main__":
    main()
